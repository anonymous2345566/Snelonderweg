// Eind-tot-eind test van de app-logica in jsdom met nagebootste API's.
// Gebruik: node test/flow.test.js (jsdom moet geïnstalleerd zijn)
const fs = require('fs');
const path = require('path');
const { JSDOM } = require(process.env.JSDOM_PATH || 'jsdom');

const WWW = path.join(__dirname, '..', 'www');
const html = fs.readFileSync(path.join(WWW, 'index.html'), 'utf8')
  .replace(/<script src="[^"]+"><\/script>/g, '');

// Nep-route: Finsterwolde -> Winschoten, rechtdoor, dan rechtsaf, rotonde, aankomst
function fakeRoute(mode) {
  const pts = [];
  for (let i = 0; i <= 40; i++) pts.push([7.0900 - i * 0.0010, 53.1580, 0]);        // west
  for (let i = 1; i <= 30; i++) pts.push([7.0500, 53.1580 - i * 0.0008, 0]);        // zuid (rechtsaf vanuit west)
  for (let i = 1; i <= 20; i++) pts.push([7.0500 - i * 0.0008, 53.1340, 0]);        // west
  return {
    type: 'FeatureCollection',
    features: [{ type: 'Feature', properties: {
      'track-length': '6400', 'total-time': mode === 'snor' ? '1100' : '700',
      voicehints: [[40, 5, 0, 2670, 90], [70, 13, 2, 1100, -20]],
      messages: [['Longitude', 'Latitude', 'Elevation', 'Distance', 'CostPerKm', 'ElevCost', 'TurnCost', 'NodeCost', 'InitialCost', 'WayTags', 'NodeTags', 'Time', 'Energy'],
        ['7090000', '53158000', '0', '2700', '0', '0', '0', '0', '0', mode === 'snor' ? 'highway=cycleway' : 'highway=secondary', '', '0', '0'],
        ['7050000', '53134000', '0', '3700', '0', '0', '0', '0', '0', 'highway=residential', '', '0', '0']]
    }, geometry: { type: 'LineString', coordinates: pts } }]
  };
}

const calls = [];
async function fakeFetch(url, opt = {}) {
  url = String(url); calls.push((opt.method || 'GET') + ' ' + url);
  const ok = (body) => ({ ok: true, status: 200, json: async () => body, text: async () => (typeof body === 'string' ? body : JSON.stringify(body)) });
  if (url.startsWith('profiles/')) return ok(fs.readFileSync(path.join(WWW, url), 'utf8'));
  if (url.includes('brouter.de/brouter/profile')) return ok({ profileid: 'custom_' + (url.includes('snor') ? 1 : Math.floor(Math.random() * 1e6)) });
  if (url.includes('brouter.de/brouter?')) {
    if (!/lonlats=[\d.]+,[\d.]+\|[\d.]+,[\d.]+/.test(url)) throw new Error('bad lonlats ' + url);
    if (!/profile:vmax=\d+/.test(url)) throw new Error('vmax missing');
    const vm = +/profile:vmax=(\d+)/.exec(url)[1];
    return ok(fakeRoute(vm <= 25 ? 'snor' : 'brom'));
  }
  if (url.includes('/reverse?') && url.includes('fl=gemeentecode')) return ok({ response: { docs: [{ gemeentecode: '1966' }] } });
  if (url.includes('/reverse?')) return ok({ response: { docs: [{ weergavenaam: 'Hoofdstraat, Winschoten' }] } });
  if (url.includes('/suggest?')) return ok({ response: { docs: [{ id: 'adr-1', weergavenaam: 'Dollard College, Winschoten', type: 'adres' }] } });
  if (url.includes('/lookup?')) return ok({ response: { docs: [{ weergavenaam: 'Winschoten', centroide_ll: 'POINT(7.034 53.144)' }] } });
  if (url.includes('photon')) return ok({ features: [] });
  if (url.includes('open-meteo')) {
    const now = new Date(); now.setMinutes(Math.floor(now.getMinutes() / 15) * 15, 0, 0);
    const time = [], pr = [];
    for (let i = 0; i < 12; i++) { const t = new Date(now.getTime() + i * 900e3); time.push(new Date(t.getTime() - t.getTimezoneOffset() * 60e3).toISOString().slice(0, 16)); pr.push(i < 2 ? 0.6 : 0); }
    const one = { minutely_15: { time, precipitation: pr }, current: { temperature_2m: 6, wind_speed_10m: 18, wind_gusts_10m: 38 } };
    return ok(url.includes(',') && url.includes('latitude=') && /latitude=[\d.]+,/.test(url) ? [one, one] : one);
  }
  if (url.includes('data.ndw.nu')) {
    return ok(url.includes('C13') ? [{ rvv_code: 'C13', text_signs: [], location: { wgs84: { latitude: 53.1580, longitude: 7.0700 }, road: { name: 'Hoofdweg' } } }] : []);
  }
  throw new Error('onbekende url ' + url);
}

class FakeMarker { constructor() { } setLngLat(ll) { this.ll = ll; return this; } addTo() { return this; } remove() { return this; } setRotation(r) { this.rot = r; return this; } }
class FakeBounds { constructor(a) { this.a = a; } extend() { return this; } }
function makeMaplibre(window) {
  const sources = {};
  const handlers = {};
  return {
    Map: class { constructor() { this._c = { lng: 6.56, lat: 53.21 }; setTimeout(() => (handlers.load || []).forEach((f) => f()), 0); }
      on(ev, f) { (handlers[ev] = handlers[ev] || []).push(f); } addControl() {} addSource(id) { sources[id] = { data: null, setData(d) { this.data = d; } }; }
      addLayer() {} getLayer() { return true; } getSource(id) { return sources[id]; } setPaintProperty() {}
      fitBounds() {} easeTo(o) { this.last = o; } jumpTo() {} setPadding() {} getCenter() { return this._c; } },
    Marker: FakeMarker, LngLatBounds: FakeBounds, NavigationControl: class {},
    _sources: sources
  };
}

(async () => {
  const dom = new JSDOM(html, { url: 'https://snelonderweg.test/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  w.fetch = fakeFetch;
  w.maplibregl = makeMaplibre(w);
  w.ResizeObserver = class { observe() {} };
  const spoken = [];
  w.speechSynthesis = { getVoices: () => [{ lang: 'nl-NL' }], cancel() {}, speak(u) { spoken.push(u.text); } };
  w.SpeechSynthesisUtterance = class { constructor(t) { this.text = t; } };
  let geoCb;
  w.navigator.geolocation = { watchPosition(cb) { geoCb = cb; setTimeout(() => cb({ coords: { latitude: 53.158, longitude: 7.09, speed: 0, heading: null, accuracy: 8 } }), 5); return 1; } };
  w.HTMLDialogElement.prototype.showModal = function () { this.open = true; };
  w.eval(fs.readFileSync(path.join(WWW, 'app.js'), 'utf8'));
  const so = w.__so;
  const doc = w.document;
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const assert = (c, m) => { if (!c) { console.error('FAIL:', m); process.exitCode = 1; } else console.log('ok  ', m); };

  await wait(50);
  assert(so.S.here && so.S.here.lat === 53.158, 'GPS-positie ontvangen');

  // Bestemming kiezen
  so.setPoint('to', { lng: 7.034, lat: 53.134, name: 'Dollard College, Winschoten' });
  await wait(200);
  assert(so.S.routes.snor && so.S.routes.brom, 'routes voor snor én brom berekend');
  assert(doc.getElementById('cmpSnor').textContent === '18 min', 'snor-tijd getoond: ' + doc.getElementById('cmpSnor').textContent);
  assert(doc.getElementById('cmpBrom').textContent === '12 min', 'brom-tijd getoond: ' + doc.getElementById('cmpBrom').textContent);
  assert(/fietspad/.test(doc.getElementById('sumDist').textContent), 'fietspad-aandeel in samenvatting: ' + doc.getElementById('sumDist').textContent);
  assert(!doc.getElementById('weatherBox').hidden, 'weerblok zichtbaar: ' + doc.getElementById('weatherText').textContent);
  assert(/Vertrek om/.test(doc.getElementById('weatherText').textContent), 'droog-vertrekadvies gegeven');
  assert(/C13/.test(doc.getElementById('warnList').innerHTML), 'NDW-bord C13 langs route gevonden');
  assert(/Hoofdstraat/.test(doc.getElementById('stepList').innerHTML), 'straatnamen in stappen');
  assert(/Rotonde: 2e afslag/.test(doc.getElementById('stepList').innerHTML), 'rotonde-instructie');
  assert(calls.some((c) => c.startsWith('POST https://brouter.de/brouter/profile')), 'profiel geüpload');

  // Moduswissel
  so.setMode('brom');
  assert(doc.body.classList.contains('mode-brom'), 'brom-modus actief');
  assert(doc.getElementById('sumTime').textContent === '12', 'samenvatting volgt brom');

  // Navigatie met echte (nep) GPS-updates
  await so.startNav();
  assert(!doc.getElementById('navTop').hidden, 'navigatiescherm open');
  assert(/Sla rechtsaf/.test(doc.getElementById('navText').textContent), 'eerste instructie: ' + doc.getElementById('navText').textContent);
  const r = so.S.routes.brom;
  const feed = (lng, lat, spd = 12) => geoCb({ coords: { latitude: lat, longitude: lng, speed: spd, heading: 270, accuracy: 6 } });
  // rij naar 60 m voor de afslag (afslag op lng 7.05)
  feed(7.0509, 53.1580);
  assert(/Over .* rechtsaf/i.test(spoken.join(' | ')), 'aankondiging rechtsaf uitgesproken');
  feed(7.0501, 53.1580);
  feed(7.0500, 53.1570); // na de afslag
  assert(/Rotonde/.test(doc.getElementById('navText').textContent), 'volgende stap is rotonde: ' + doc.getElementById('navText').textContent);
  assert(+doc.getElementById('speedVal').textContent === 43, 'snelheid getoond (43 km/h)');
  // ver van de route -> herberekening na 3 keer
  const before = calls.filter((c) => c.includes('brouter.de/brouter?')).length;
  feed(7.0600, 53.1500); feed(7.0601, 53.1500); feed(7.0602, 53.1500);
  await wait(50);
  const after = calls.filter((c) => c.includes('brouter.de/brouter?')).length;
  assert(after === before + 1, 'route opnieuw berekend na afwijken');
  // aankomst
  const end = so.S.routes.brom.coords[so.S.routes.brom.coords.length - 1];
  feed(end[0], end[1]);
  assert(/aangekomen/.test(spoken.join(' | ')), 'aankomst uitgesproken');
  so.stopNav();
  assert(doc.getElementById('navTop').hidden && !doc.getElementById('sheet').hidden, 'navigatie gestopt, paneel terug');
  console.log('\nGesproken:', spoken.join('\n  '));
})().catch((e) => { console.error(e); process.exitCode = 1; });
