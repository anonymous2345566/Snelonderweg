/* SnelOnderweg service worker: app-schil offline, kaarttegels op de achtergrond bewaren */
const SHELL = 'so-shell-v1';
const TILES = 'so-tiles-v1';
const FILES = ['./', './index.html', './style.css', './app.js', './manifest.webmanifest',
  './vendor/maplibre-gl.js', './vendor/maplibre-gl.css', './profiles/snor.brf', './profiles/brom.brf',
  './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => ![SHELL, TILES].includes(k)).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // Eigen bestanden: netwerk eerst (altijd nieuwste versie), cache als je offline bent
  if (url.origin === location.origin) {
    e.respondWith(fetch(e.request).then((r) => {
      const copy = r.clone(); caches.open(SHELL).then((c) => c.put(e.request, copy)); return r;
    }).catch(() => caches.match(e.request, { ignoreSearch: true })));
    return;
  }
  // Kaartstijl, tegels en lettertypes van OpenFreeMap: cache eerst
  if (url.hostname === 'tiles.openfreemap.org') {
    e.respondWith(caches.open(TILES).then(async (c) => {
      const hit = await c.match(e.request);
      if (hit) return hit;
      const r = await fetch(e.request);
      if (r.ok) { c.put(e.request, r.clone()); trim(c); }
      return r;
    }));
  }
});
let trimming = false;
async function trim(c) {
  if (trimming) return; trimming = true;
  try { const keys = await c.keys(); for (let i = 0; i < keys.length - 3000; i++) await c.delete(keys[i]); } finally { trimming = false; }
}
