/* SnelOnderweg — navigatie voor snorfiets en bromfiets
 * Kaart: MapLibre + OpenFreeMap · Routes: BRouter met eigen profielen · Zoeken: PDOK + Photon
 * Weer: Open-Meteo · Borden: NDW open data
 */
'use strict';

/* ================= Config ================= */
const CFG = {
  brouter: 'https://brouter.de/brouter',
  pdok: 'https://api.pdok.nl/bzk/locatieserver/search/v3_1',
  photon: 'https://photon.komoot.io/api/',
  meteo: 'https://api.open-meteo.com/v1/forecast',
  ndw: 'https://data.ndw.nu/api/rest/static-road-data/traffic-signs/v1/current-state',
  styleLight: 'https://tiles.openfreemap.org/styles/liberty',
  nlBbox: [3.2, 50.7, 7.3, 53.6],
  start: { center: [6.5665, 53.2194], zoom: 12 } // Groningen
};
const MODES = {
  snor: { label: 'Snorfiets', file: 'profiles/snor.brf', color: '#1f5fbf', casing: '#ffffff', vmax: 25, far: 150, near: 50 },
  brom: { label: 'Bromfiets', file: 'profiles/brom.brf', color: '#f5c518', casing: '#14181d', vmax: 45, far: 250, near: 70 }
};
const PROFILE_VERSION = '1.0.0';

/* ================= Opslag (veilig) ================= */
const store = {
  get(k, d) { try { const v = localStorage.getItem('so_' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('so_' + k, JSON.stringify(v)); } catch { /* geen opslag */ } }
};

const settings = Object.assign({
  voice: true, vmaxSnor: 25, vmaxBrom: 45, busySnor: true, busyBrom: false, ndw: true, sim: false
}, store.get('settings', {}));
const saveSettings = () => store.set('settings', settings);

/* ================= Status ================= */
const S = {
  mode: store.get('mode', 'snor'),
  from: null,          // {lng, lat, name} of null = huidige locatie
  to: null,
  here: null,          // laatste GPS-positie {lng, lat, speed, heading, acc}
  routes: {},          // per modus
  altIdx: 0,
  nav: null,           // navigatiestatus
  activeInput: null
};

/* ================= Hulpfuncties ================= */
const $ = (id) => document.getElementById(id);
const R = 6371008.8;
const toRad = (d) => d * Math.PI / 180;
function hav(a, b) { // [lng,lat]
  const dLat = toRad(b[1] - a[1]), dLng = toRad(b[0] - a[0]);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a[1])) * Math.cos(toRad(b[1])) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
function bearing(a, b) {
  const y = Math.sin(toRad(b[0] - a[0])) * Math.cos(toRad(b[1]));
  const x = Math.cos(toRad(a[1])) * Math.sin(toRad(b[1])) - Math.sin(toRad(a[1])) * Math.cos(toRad(b[1])) * Math.cos(toRad(b[0] - a[0]));
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
// Projectie van punt p op segment a-b in lokale meters
function projectOnSeg(p, a, b) {
  const kx = Math.cos(toRad(p[1])) * 111320, ky = 110540;
  const ax = (a[0] - p[0]) * kx, ay = (a[1] - p[1]) * ky;
  const bx = (b[0] - p[0]) * kx, by = (b[1] - p[1]) * ky;
  const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy;
  let t = L2 ? -(ax * dx + ay * dy) / L2 : 0;
  t = Math.max(0, Math.min(1, t));
  const qx = ax + t * dx, qy = ay + t * dy;
  return { t, d: Math.hypot(qx, qy) };
}
function fmtDist(m) {
  if (m < 100) return Math.max(10, Math.round(m / 10) * 10) + ' m';
  if (m < 1000) return Math.round(m / 50) * 50 + ' m';
  return (m / 1000).toFixed(m < 10000 ? 1 : 0).replace('.', ',') + ' km';
}
function speakDist(m) {
  if (m < 1000) return (m < 100 ? Math.max(10, Math.round(m / 10) * 10) : Math.round(m / 50) * 50) + ' meter';
  const km = (m / 1000).toFixed(1).replace('.0', '');
  return km.replace('.', ' komma ') + ' kilometer';
}
const fmtMin = (s) => Math.max(1, Math.round(s / 60));
const fmtClock = (d) => d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
let toastT;
function toast(msg, ms = 3200) {
  const el = $('toast'); el.textContent = msg; el.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => { el.hidden = true; }, ms);
}
async function fetchJSON(url, opt = {}, timeout = 20000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { ...opt, signal: ctl.signal });
    if (!r.ok) { const txt = await r.text().catch(() => ''); const e = new Error(txt || ('HTTP ' + r.status)); e.status = r.status; throw e; }
    return await r.json();
  } finally { clearTimeout(t); }
}
const cap = () => window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() ? window.Capacitor.Plugins : null;

/* ================= Kaart ================= */
const map = new maplibregl.Map({
  container: 'map', style: CFG.styleLight, center: CFG.start.center, zoom: CFG.start.zoom,
  attributionControl: { compact: true }, pitchWithRotate: true, dragRotate: true
});
map.addControl(new maplibregl.NavigationControl({ showZoom: false, visualizePitch: true }), 'bottom-right');

const puckEl = document.createElement('div');
puckEl.className = 'puck'; puckEl.innerHTML = '<div class="cone"></div>';
const puck = new maplibregl.Marker({ element: puckEl, rotationAlignment: 'map', pitchAlignment: 'map' });
let puckOnMap = false;
const destMarker = new maplibregl.Marker({ color: '#e5484d' });
const fromMarker = new maplibregl.Marker({ color: '#eef2f5', scale: 0.7 });
let signMarkers = [];

const EMPTY = { type: 'FeatureCollection', features: [] };
let styleWarned = false;
map.on('error', () => {
  if (!map.isStyleLoaded() && !styleWarned) { styleWarned = true; toast('De kaart kon niet laden. Heb je internet?', 5000); }
});
map.on('load', () => {
  map.addSource('route', { type: 'geojson', data: EMPTY, lineMetrics: true });
  map.addSource('done', { type: 'geojson', data: EMPTY });
  map.addLayer({ id: 'route-casing', type: 'line', source: 'route', layout: { 'line-cap': 'round', 'line-join': 'round' },
    paint: { 'line-color': '#ffffff', 'line-width': ['interpolate', ['linear'], ['zoom'], 10, 7, 16, 14, 19, 26] } });
  map.addLayer({ id: 'route-line', type: 'line', source: 'route', layout: { 'line-cap': 'round', 'line-join': 'round' },
    paint: { 'line-color': MODES.snor.color, 'line-width': ['interpolate', ['linear'], ['zoom'], 10, 4, 16, 9, 19, 18] } });
  map.addLayer({ id: 'done-line', type: 'line', source: 'done', layout: { 'line-cap': 'round', 'line-join': 'round' },
    paint: { 'line-color': '#8a96a3', 'line-width': ['interpolate', ['linear'], ['zoom'], 10, 4, 16, 9, 19, 18] } });
  applyModeStyle();
  if (S.routes[S.mode]) drawRoute();
});

function applyModeStyle() {
  document.body.classList.toggle('mode-brom', S.mode === 'brom');
  document.querySelectorAll('.plate').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.mode === S.mode)));
  document.querySelectorAll('.cmp').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.mode === S.mode)));
  if (map.getLayer('route-line')) {
    map.setPaintProperty('route-line', 'line-color', MODES[S.mode].color);
    map.setPaintProperty('route-casing', 'line-color', MODES[S.mode].casing);
  }
  document.querySelector('.plate-snor .plate-speed').textContent = settings.vmaxSnor;
  document.querySelector('.plate-brom .plate-speed').textContent = settings.vmaxBrom;
}

/* ================= Locatie ================= */
let geoWatch = null;
function startGeo() {
  if (geoWatch != null) return;
  const onPos = (c) => {
    if (S.nav && S.nav.sim) return; // tijdens simulatie negeren
    S.here = { lng: c.longitude, lat: c.latitude, speed: c.speed, heading: c.heading, acc: c.accuracy, t: Date.now() };
    updatePuck();
    if (S.nav) onNavPosition();
  };
  const P = cap();
  if (P && P.Geolocation) {
    P.Geolocation.requestPermissions().catch(() => {}).finally(() => {
      P.Geolocation.watchPosition({ enableHighAccuracy: true, timeout: 15000, maximumAge: 1000 }, (pos, err) => {
        if (pos) onPos(pos.coords); else if (err) geoError(err);
      }).then((id) => { geoWatch = id; });
    });
    geoWatch = 'pending';
  } else if ('geolocation' in navigator) {
    geoWatch = navigator.geolocation.watchPosition((p) => onPos(p.coords), geoError,
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 15000 });
  } else {
    toast('Deze telefoon geeft geen locatie door.');
  }
}
function geoError(e) {
  if (e && e.code === 1) toast('Geef SnelOnderweg toegang tot je locatie om te navigeren.', 5000);
}
function updatePuck() {
  if (!S.here) return;
  puck.setLngLat([S.here.lng, S.here.lat]);
  if (!puckOnMap) { puck.addTo(map); puckOnMap = true; }
}
function whenHere(timeout = 12000) {
  if (S.here && Date.now() - S.here.t < 60000) return Promise.resolve(S.here);
  startGeo();
  return new Promise((res, rej) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (S.here) { clearInterval(iv); res(S.here); }
      else if (Date.now() - t0 > timeout) { clearInterval(iv); rej(new Error('Geen GPS-positie')); }
    }, 250);
  });
}
$('btnLocate').addEventListener('click', async () => {
  try { const h = await whenHere(); map.easeTo({ center: [h.lng, h.lat], zoom: 16 }); }
  catch { toast('Je locatie is nog niet gevonden. Sta je buiten?'); }
});

/* ================= Zoeken (PDOK + Photon) ================= */
const sugEl = $('suggest');
let sugItems = [];
async function searchPlaces(q) {
  q = q.trim();
  if (q.length < 2) return [];
  const near = S.here ? `&lat=${S.here.lat}&lon=${S.here.lng}` : `&lat=${map.getCenter().lat}&lon=${map.getCenter().lng}`;
  const pdokP = fetchJSON(`${CFG.pdok}/suggest?q=${encodeURIComponent(q)}&rows=6&fq=type:(adres OR weg OR woonplaats OR postcode OR gemeente)`, {}, 8000)
    .then((j) => (j.response.docs || []).map((d) => ({ src: 'pdok', id: d.id, name: d.weergavenaam, type: d.type })))
    .catch(() => []);
  const photonP = fetchJSON(`${CFG.photon}?q=${encodeURIComponent(q)}&limit=6&lang=default${near}&bbox=${CFG.nlBbox.join(',')}`, {}, 8000)
    .then((j) => (j.features || [])
      .filter((f) => f.properties && f.properties.countrycode === 'NL' && !['highway', 'place', 'boundary'].includes(f.properties.osm_key))
      .map((f) => {
        const p = f.properties;
        const sub = [p.street && (p.street + (p.housenumber ? ' ' + p.housenumber : '')), p.city || p.town || p.village].filter(Boolean).join(', ');
        return { src: 'photon', name: p.name || sub, sub, type: 'plek', lng: f.geometry.coordinates[0], lat: f.geometry.coordinates[1] };
      }))
    .catch(() => []);
  const [a, b] = await Promise.all([pdokP, photonP]);
  // Plekken (scholen, winkels) eerst als de zoekterm geen adres lijkt
  const looksAddress = /\d/.test(q);
  return (looksAddress ? [...a, ...b] : [...b.slice(0, 3), ...a, ...b.slice(3)]).slice(0, 9);
}
async function resolvePlace(it) {
  if (it.src === 'photon' || it.src === 'fav' || it.src === 'recent') return { lng: it.lng, lat: it.lat, name: it.name };
  const j = await fetchJSON(`${CFG.pdok}/lookup?id=${encodeURIComponent(it.id)}&fl=centroide_ll,weergavenaam`);
  const d = j.response.docs[0];
  const m = /POINT\(([-\d.]+) ([-\d.]+)\)/.exec(d.centroide_ll);
  return { lng: +m[1], lat: +m[2], name: d.weergavenaam };
}
function renderSuggest(items, withHere) {
  sugItems = items;
  const rows = [];
  if (withHere) rows.push('<li data-i="here"><b>◎ Huidige locatie</b></li>');
  items.forEach((it, i) => {
    const typ = { adres: 'Adres', weg: 'Straat', woonplaats: 'Plaats', postcode: 'Postcode', gemeente: 'Gemeente', plek: 'Plek' }[it.type] || '';
    rows.push(`<li data-i="${i}"><b>${esc(it.name)}</b><small>${esc([typ, it.sub].filter(Boolean).join(' · '))}</small></li>`);
  });
  sugEl.innerHTML = rows.join('');
  sugEl.hidden = rows.length === 0;
}
const doSearch = debounce(async (input) => {
  const q = input.value;
  const items = await searchPlaces(q);
  if (S.activeInput === input && input.value === q) renderSuggest(items, input === $('inFrom'));
}, 220);
['inFrom', 'inTo'].forEach((id) => {
  const el = $(id);
  el.addEventListener('focus', () => { S.activeInput = el; if (id === 'inFrom' && !el.value) renderSuggest([], true); });
  el.addEventListener('input', () => { S.activeInput = el; doSearch(el); });
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && sugItems.length) { e.preventDefault(); pickSuggestion('0'); }
    if (e.key === 'Escape') { sugEl.hidden = true; el.blur(); }
  });
});
sugEl.addEventListener('pointerdown', (e) => { e.preventDefault(); });
sugEl.addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) pickSuggestion(li.dataset.i); });
document.addEventListener('pointerdown', (e) => { if (!e.target.closest('.search')) sugEl.hidden = true; });

async function pickSuggestion(i) {
  const input = S.activeInput || $('inTo');
  sugEl.hidden = true; input.blur();
  if (i === 'here') { S.from = null; $('inFrom').value = ''; planRoute(); return; }
  try {
    const p = await resolvePlace(sugItems[+i]);
    setPoint(input === $('inFrom') ? 'from' : 'to', p);
  } catch { toast('Dit adres kon niet worden opgezocht. Probeer het nog eens.'); }
}
function setPoint(which, p) {
  S[which] = p;
  $(which === 'from' ? 'inFrom' : 'inTo').value = p ? p.name : '';
  if (which === 'to' && p) addRecent(p);
  S.altIdx = 0;
  planRoute();
}
$('btnSwap').addEventListener('click', async () => {
  let from = S.from;
  if (!from) { try { const h = await whenHere(); from = { lng: h.lng, lat: h.lat, name: 'Mijn locatie' }; } catch { toast('Je locatie is nog niet gevonden.'); return; } }
  const to = S.to; S.from = to; S.to = from;
  $('inFrom').value = to ? to.name : ''; $('inTo').value = from ? from.name : '';
  planRoute();
});

/* Kaart lang indrukken -> bestemming */
let pressT = null, pressPt = null;
function pressStart(e) {
  const t = e.originalEvent.touches; if (t && t.length > 1) return;
  pressPt = e.point; clearTimeout(pressT);
  pressT = setTimeout(() => pickOnMap(e.lngLat), 550);
}
function pressMove(e) { if (pressPt && (Math.abs(e.point.x - pressPt.x) > 8 || Math.abs(e.point.y - pressPt.y) > 8)) clearTimeout(pressT); }
map.on('touchstart', pressStart); map.on('touchmove', pressMove); map.on('touchend', () => clearTimeout(pressT));
map.on('contextmenu', (e) => pickOnMap(e.lngLat));
async function pickOnMap(ll) {
  if (S.nav) return;
  if (navigator.vibrate) navigator.vibrate(20);
  let name = `${ll.lat.toFixed(5)}, ${ll.lng.toFixed(5)}`;
  try {
    const j = await fetchJSON(`${CFG.pdok}/reverse?lat=${ll.lat}&lon=${ll.lng}&rows=1&type=adres`, {}, 6000);
    if (j.response.docs[0]) name = j.response.docs[0].weergavenaam;
  } catch { /* coördinaten blijven staan */ }
  setPoint('to', { lng: ll.lng, lat: ll.lat, name });
}

/* ================= Favorieten & recent ================= */
function favs() { return store.get('favs', {}); }
function renderHome() {
  const f = favs();
  $('favHomeLbl').textContent = f.home ? f.home.name : 'Nog niet ingesteld';
  $('favWorkLbl').textContent = f.work ? f.work.name : 'Nog niet ingesteld';
  const rec = store.get('recent', []);
  $('recentList').innerHTML = rec.length
    ? rec.map((r, i) => `<li data-i="${i}"><span>${esc(r.name.split(',')[0])}</span><small>${esc(r.name.split(',').slice(1).join(',').trim())}</small></li>`).join('')
    : '<li class="empty">Je zoekopdrachten verschijnen hier.</li>';
}
function addRecent(p) {
  const rec = store.get('recent', []).filter((r) => r.name !== p.name);
  rec.unshift({ name: p.name, lng: p.lng, lat: p.lat });
  store.set('recent', rec.slice(0, 8));
}
$('recentList').addEventListener('click', (e) => {
  const li = e.target.closest('li[data-i]'); if (!li) return;
  const r = store.get('recent', [])[+li.dataset.i]; if (r) setPoint('to', r);
});
document.querySelectorAll('.quick-btn').forEach((b) => b.addEventListener('click', () => {
  const f = favs()[b.dataset.fav];
  if (f) setPoint('to', f);
  else toast('Plan eerst een route en kies dan "Bewaar als ' + (b.dataset.fav === 'home' ? 'Thuis' : 'Werk/school') + '".', 4500);
}));
function saveFav(key) {
  if (!S.to) return;
  const f = favs(); f[key] = { name: S.to.name, lng: S.to.lng, lat: S.to.lat }; store.set('favs', f);
  toast((key === 'home' ? 'Thuis' : 'Werk/school') + ' bewaard'); renderHome();
}
$('btnSaveHome').addEventListener('click', () => saveFav('home'));
$('btnSaveWork').addEventListener('click', () => saveFav('work'));

/* ================= Routeprofielen (BRouter) ================= */
async function profileId(mode, force) {
  const key = 'prof_' + mode;
  const c = store.get(key);
  if (!force && c && c.v === PROFILE_VERSION && Date.now() - c.t < 6 * 3600e3) return c.id;
  const text = await (await fetch(MODES[mode].file, { cache: 'no-cache' })).text();
  const url = CFG.brouter + '/profile' + (c && c.id && c.v === PROFILE_VERSION ? '/' + c.id : '');
  // text/plain houdt het een "simple request" (geen CORS-preflight nodig)
  const j = await fetchJSON(url, { method: 'POST', body: text, headers: { 'Content-Type': 'text/plain' } });
  if (j.error) throw new Error('Profiel geweigerd: ' + j.error);
  store.set(key, { id: j.profileid, t: Date.now(), v: PROFILE_VERSION });
  return j.profileid;
}

async function fetchRoute(mode, from, to, alt = 0, retried = false) {
  const id = await profileId(mode, retried);
  const vmax = mode === 'snor' ? settings.vmaxSnor : settings.vmaxBrom;
  const busy = mode === 'snor' ? settings.busySnor : settings.busyBrom;
  const url = `${CFG.brouter}?lonlats=${from[0].toFixed(6)},${from[1].toFixed(6)}|${to[0].toFixed(6)},${to[1].toFixed(6)}` +
    `&profile=${id}&alternativeidx=${alt}&format=geojson&timode=2&profile:vmax=${vmax}&profile:avoid_busy=${busy ? 1 : 0}`;
  try {
    const geo = await fetchJSON(url, {}, 45000);
    return parseRoute(geo, mode);
  } catch (e) {
    const msg = String(e.message || '');
    if (!retried && /profile|custom_|not found|unknown/i.test(msg)) return fetchRoute(mode, from, to, alt, true);
    if (/from-position not mapped|to-position not mapped|not mapped/i.test(msg)) throw new Error('Dit punt ligt niet bij een weg waar je mag rijden.');
    if (/no track found|target island|unreachable/i.test(msg)) throw new Error('Geen legale route gevonden voor dit kenteken.');
    throw new Error(e.name === 'AbortError' ? 'De routeserver reageert niet. Probeer het zo weer.' : 'Route niet gelukt: ' + msg.slice(0, 120));
  }
}

function parseRoute(geo, mode) {
  const f = geo.features[0];
  const coords = f.geometry.coordinates.map((c) => [c[0], c[1]]);
  const cum = [0];
  for (let i = 1; i < coords.length; i++) cum[i] = cum[i - 1] + hav(coords[i - 1], coords[i]);
  const p = f.properties;
  const steps = (p.voicehints || []).map((h) => ({ idx: h[0], cmd: h[1], exit: h[2], angle: h[4], name: '' }))
    .filter((s) => s.idx > 0 && s.idx < coords.length - 1);
  steps.push({ idx: coords.length - 1, cmd: 100, exit: 0, name: '' });
  // Wegtypes langs de route (voor bijv. "fietspad" in de samenvatting)
  let cyclePathM = 0;
  const msgs = p.messages || [];
  for (let i = 1; i < msgs.length; i++) {
    const tags = msgs[i][9] || '', dist = +msgs[i][3] || 0;
    if (/highway=cycleway|bicycle=designated/.test(tags)) cyclePathM += dist;
  }
  return {
    mode, coords, cum, steps,
    length: +p['track-length'] || cum[cum.length - 1],
    time: +p['total-time'] || cum[cum.length - 1] / (MODES[mode].vmax / 3.6),
    cyclePathM
  };
}

/* ================= Route plannen ================= */
let planSeq = 0;
async function planRoute() {
  if (!S.to) return;
  const seq = ++planSeq;
  let from = S.from;
  if (!from) {
    try { const h = await whenHere(); from = { lng: h.lng, lat: h.lat, name: 'Mijn locatie' }; }
    catch { toast('Je locatie is nog niet gevonden. Vul een vertrekpunt in.', 4500); $('inFrom').focus(); return; }
  }
  if (seq !== planSeq) return;
  showPane('route');
  $('cmpSnor').textContent = '…'; $('cmpBrom').textContent = '…';
  $('sumTime').textContent = '…'; $('sumDist').textContent = 'Route berekenen…'; $('sumEta').textContent = '';
  $('warnList').innerHTML = ''; $('weatherBox').hidden = true; $('stepList').hidden = true;
  destMarker.setLngLat([S.to.lng, S.to.lat]).addTo(map);
  if (S.from) fromMarker.setLngLat([S.from.lng, S.from.lat]).addTo(map); else fromMarker.remove();
  clearSigns();
  S.routes = {};
  const a = [from.lng, from.lat], b = [S.to.lng, S.to.lat];
  const jobs = ['snor', 'brom'].map((m) => fetchRoute(m, a, b, m === S.mode ? S.altIdx : 0)
    .then((r) => { if (seq !== planSeq) return; S.routes[m] = r; $(m === 'snor' ? 'cmpSnor' : 'cmpBrom').textContent = fmtMin(r.time) + ' min'; if (m === S.mode) showRoute(true); })
    .catch((e) => { if (seq !== planSeq) return; $(m === 'snor' ? 'cmpSnor' : 'cmpBrom').textContent = '—'; if (m === S.mode) { $('sumDist').textContent = e.message; $('sumTime').textContent = '–'; } }));
  await Promise.all(jobs);
}

function showRoute(fit) {
  const r = S.routes[S.mode];
  if (!r) { $('sumTime').textContent = '–'; $('sumDist').textContent = 'Geen route voor dit kenteken'; return; }
  $('sumTime').textContent = fmtMin(r.time);
  $('sumDist').textContent = fmtDist(r.length) + (r.cyclePathM > 200 ? ` · ${Math.round(100 * r.cyclePathM / r.length)}% fietspad` : '');
  $('sumEta').textContent = 'Aankomst ' + fmtClock(new Date(Date.now() + r.time * 1000));
  drawRoute();
  if (fit) {
    const bb = r.coords.reduce((b, c) => b.extend(c), new maplibregl.LngLatBounds(r.coords[0], r.coords[0]));
    const sheetH = $('sheet').offsetHeight, topH = $('topbar').offsetHeight;
    const wide = window.innerWidth >= 760;
    map.fitBounds(bb, { padding: wide ? { top: 60, bottom: 60, left: 460, right: 60 } : { top: topH + 30, bottom: sheetH + 30, left: 40, right: 40 }, duration: 600, maxZoom: 16 });
  }
  renderSteps(r);
  buildWarnings(r);
  loadWeather(r);
  if (settings.ndw) checkSigns(r);
  nameSteps(r);
}
function drawRoute() {
  const r = S.routes[S.mode];
  if (!map.getSource('route')) return;
  map.getSource('route').setData(r ? { type: 'Feature', geometry: { type: 'LineString', coordinates: r.coords } } : EMPTY);
  map.getSource('done').setData(EMPTY);
}

function buildWarnings(r) {
  const li = [];
  if (r.mode === 'snor') li.push('<li class="info">Helm verplicht op de snorfiets (sinds 2023).</li>');
  if (r.mode === 'brom' && r.cyclePathM > 0) li.push(`<li class="info">${fmtDist(r.cyclePathM)} over fiets/bromfietspad (G12a).</li>`);
  $('warnList').innerHTML = li.join('');
}

/* ================= Stappen & straatnamen ================= */
const CMD = {
  1: ['Ga rechtdoor', 0], 2: ['Sla linksaf', -90], 3: ['Flauwe bocht naar links', -40], 4: ['Sla scherp linksaf', -135],
  5: ['Sla rechtsaf', 90], 6: ['Flauwe bocht naar rechts', 40], 7: ['Sla scherp rechtsaf', 135],
  8: ['Houd links aan', -25], 9: ['Houd rechts aan', 25], 10: ['Keer om', -180], 11: ['Keer om', 180], 15: ['Keer om', -180],
  13: ['Rotonde', 0], 14: ['Rotonde', 0], 16: ['Rij rechtstreeks naar het doel', 0], 17: ['Neem de afslag links', -45], 18: ['Neem de afslag rechts', 45],
  100: ['Je bent aangekomen', 0]
};
const ORD = ['', 'eerste', 'tweede', 'derde', 'vierde', 'vijfde', 'zesde', 'zevende', 'achtste'];
function stepText(s, spoken) {
  if (s.cmd === 13 || s.cmd === 14) {
    const n = Math.abs(s.exit || 1);
    const t = spoken ? `Neem op de rotonde de ${ORD[n] || n + 'e'} afslag` : `Rotonde: ${n}e afslag`;
    return t + (s.name ? ' naar ' + s.name : '');
  }
  const base = (CMD[s.cmd] || ['Ga verder', 0])[0];
  if (s.cmd === 100) return base;
  return base + (s.name ? (s.cmd === 1 ? ' op ' : ' naar ') + s.name : '');
}
function arrowSVG(s, color = 'currentColor') {
  if (s.cmd === 100) {
    return `<svg viewBox="0 0 100 100"><path d="M50 8c-15 0-27 12-27 27 0 20 27 55 27 55s27-35 27-55C77 20 65 8 50 8z" fill="${color}"/><circle cx="50" cy="35" r="10" fill="#14181d"/></svg>`;
  }
  if (s.cmd === 13 || s.cmd === 14) {
    const n = Math.abs(s.exit || 1);
    return `<svg viewBox="0 0 100 100"><circle cx="50" cy="45" r="24" fill="none" stroke="${color}" stroke-width="9"/><path d="M50 95V70" stroke="${color}" stroke-width="10" stroke-linecap="round"/><text x="50" y="56" text-anchor="middle" font-family="Barlow Condensed,sans-serif" font-weight="700" font-size="32" fill="${color}">${n}</text></svg>`;
  }
  let a = (CMD[s.cmd] || [0, 0])[1];
  if (Math.abs(a) === 180) {
    const d = a < 0 ? 'M62 92V45a16 16 0 0 0-32 0v20' : 'M38 92V45a16 16 0 0 1 32 0v20';
    const hx = a < 0 ? 30 : 70;
    return `<svg viewBox="0 0 100 100"><path d="${d}" fill="none" stroke="${color}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M${hx - 16} 60L${hx} 82L${hx + 16} 60z" fill="${color}"/></svg>`;
  }
  const rad = toRad(a), ex = 50 + 34 * Math.sin(rad), ey = 50 - 34 * Math.cos(rad);
  const hx = 50 + 44 * Math.sin(rad), hy = 50 - 44 * Math.cos(rad);
  const l = toRad(a - 90), r = toRad(a + 90);
  const head = `M${hx.toFixed(1)} ${hy.toFixed(1)}L${(ex + 14 * Math.sin(l)).toFixed(1)} ${(ey - 14 * Math.cos(l)).toFixed(1)}L${(ex + 14 * Math.sin(r)).toFixed(1)} ${(ey - 14 * Math.cos(r)).toFixed(1)}z`;
  return `<svg viewBox="0 0 100 100"><path d="M50 94V54L${ex.toFixed(1)} ${ey.toFixed(1)}" fill="none" stroke="${color}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="${head}" fill="${color}"/></svg>`;
}
function renderSteps(r) {
  $('stepList').innerHTML = r.steps.map((s, i) => {
    const prev = i ? r.cum[r.steps[i - 1].idx] : 0;
    return `<li><span class="sa">${arrowSVG(s)}</span><span>${esc(stepText(s))}</span><span class="sd">${fmtDist(r.cum[s.idx] - prev)}</span></li>`;
  }).join('');
}
$('btnSteps').addEventListener('click', () => { const el = $('stepList'); el.hidden = !el.hidden; });
$('btnAlt').addEventListener('click', () => {
  S.altIdx = (S.altIdx + 1) % 3;
  const r0 = S.routes[S.mode];
  if (!r0) return;
  const from = r0.coords[0], to = r0.coords[r0.coords.length - 1];
  $('sumDist').textContent = 'Andere route zoeken…';
  fetchRoute(S.mode, from, to, S.altIdx).then((r) => { S.routes[S.mode] = r; showRoute(true); toast(S.altIdx ? `Alternatief ${S.altIdx}` : 'Snelste route'); })
    .catch(() => { S.altIdx = 0; toast('Geen andere route gevonden.'); showRoute(false); });
});

// Straatnaam na elke afslag ophalen via PDOK (max 40 stappen, 4 tegelijk)
async function nameSteps(r) {
  const todo = r.steps.filter((s) => s.cmd !== 100).slice(0, 40);
  let k = 0;
  const worker = async () => {
    while (k < todo.length) {
      const s = todo[k++];
      // punt ±25 m voorbij de afslag
      let j = s.idx; while (j < r.coords.length - 1 && r.cum[j] - r.cum[s.idx] < 25) j++;
      const [lng, lat] = r.coords[j];
      try {
        const res = await fetchJSON(`${CFG.pdok}/reverse?lat=${lat}&lon=${lng}&rows=1&type=weg&distance=25`, {}, 6000);
        const d = res.response.docs[0];
        if (d) s.name = d.weergavenaam.split(',')[0];
      } catch { /* zonder naam */ }
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  if (S.routes[r.mode] === r) { renderSteps(r); if (S.nav) updateNavUI(true); }
}

/* ================= Weer (Open-Meteo) ================= */
async function loadWeather(r) {
  const a = r.coords[0], b = r.coords[r.coords.length - 1];
  try {
    const url = `${CFG.meteo}?latitude=${a[1].toFixed(3)},${b[1].toFixed(3)}&longitude=${a[0].toFixed(3)},${b[0].toFixed(3)}` +
      '&minutely_15=precipitation&current=temperature_2m,precipitation,wind_speed_10m,wind_gusts_10m&forecast_minutely_15=12&timezone=Europe%2FAmsterdam';
    let j = await fetchJSON(url, {}, 10000);
    if (!Array.isArray(j)) j = [j, j];
    if (S.routes[r.mode] !== r) return;
    const [ja, jb] = j;
    const times = ja.minutely_15.time.map((t) => new Date(t + ':00'));
    const pa = ja.minutely_15.precipitation, pb = jb.minutely_15.precipitation;
    const now = Date.now();
    // eerste kwartier dat nog loopt
    let i0 = times.findIndex((t) => t.getTime() + 15 * 60e3 > now); if (i0 < 0) i0 = 0;
    const bars = pa.slice(i0, i0 + 8);
    $('rainBars').innerHTML = bars.map((v) => `<i class="${v > 0.05 ? '' : 'dry'}" style="height:${Math.min(34, 3 + v * 14).toFixed(0)}px" title="${v} mm"></i>`).join('');
    const tripQ = Math.max(1, Math.ceil(r.time / 900));
    const rainOnTrip = (start) => {
      let mx = 0;
      for (let q = 0; q <= tripQ; q++) {
        const src = q < tripQ / 2 ? pa : pb;
        mx = Math.max(mx, src[start + q] || 0);
      }
      return mx;
    };
    const now_mm = rainOnTrip(i0);
    const txt = [];
    if (now_mm < 0.1) txt.push('Droog onderweg.');
    else {
      let dry = -1;
      for (let s = i0 + 1; s <= i0 + 6; s++) if (rainOnTrip(s) < 0.1) { dry = s; break; }
      txt.push(`Regen tijdens je rit (tot ${now_mm.toFixed(1).replace('.', ',')} mm per kwartier).`);
      if (dry > 0) txt.push(`Vertrek om ${fmtClock(times[dry])} en je blijft droog.`);
      else txt.push('De komende anderhalf uur blijft het nat. Regenpak aan.');
    }
    const c = ja.current;
    if (c.wind_gusts_10m >= 50) txt.push(`Harde windstoten (${Math.round(c.wind_gusts_10m)} km/h).`);
    if (c.temperature_2m <= 1) txt.push(`${Math.round(c.temperature_2m)} °C: kans op gladheid.`);
    else txt.push(`${Math.round(c.temperature_2m)} °C, wind ${Math.round(c.wind_speed_10m)} km/h.`);
    $('weatherText').textContent = txt.join(' ');
    $('weatherBox').hidden = false;
    r.weather = { rain: now_mm };
  } catch { /* weer is optioneel */ }
}

/* ================= Verkeersborden (NDW) ================= */
const ndwCache = new Map();
function clearSigns() { signMarkers.forEach((m) => m.remove()); signMarkers = []; }
function distToRoute(r, p) {
  let best = Infinity;
  for (let i = 0; i < r.coords.length - 1; i++) {
    const a = r.coords[i], b = r.coords[i + 1];
    if (Math.abs(a[1] - p[1]) > 0.003 && Math.abs(b[1] - p[1]) > 0.003) continue;
    if (Math.abs(a[0] - p[0]) > 0.005 && Math.abs(b[0] - p[0]) > 0.005) continue;
    best = Math.min(best, projectOnSeg(p, a, b).d);
  }
  return best;
}
async function checkSigns(r) {
  try {
    // gemeenten langs de route bepalen (ongeveer elke 2,5 km een punt)
    const pts = [];
    for (let i = 0, next = 0; i < r.coords.length; i++) if (r.cum[i] >= next) { pts.push(r.coords[i]); next += 2500; }
    pts.push(r.coords[r.coords.length - 1]);
    const codes = new Set();
    await Promise.all(pts.slice(0, 16).map(async ([lng, lat]) => {
      try {
        const j = await fetchJSON(`${CFG.pdok}/reverse?lat=${lat}&lon=${lng}&rows=1&type=weg&fl=gemeentecode&distance=500`, {}, 6000);
        const g = j.response.docs[0] && j.response.docs[0].gemeentecode;
        if (g) codes.add('GM' + String(g).padStart(4, '0'));
      } catch { /* overslaan */ }
    }));
    const signs = [];
    for (const code of [...codes].slice(0, 8)) {
      for (const rvv of ['C13', 'C15']) {
        const k = code + rvv;
        if (!ndwCache.has(k)) {
          ndwCache.set(k, fetchJSON(`${CFG.ndw}?town-code=${code}&rvv-code=${rvv}`, {}, 15000).catch(() => null));
        }
        const list = await ndwCache.get(k);
        if (list === null) throw new Error('ndw');
        (Array.isArray(list) ? list : []).forEach((s) => signs.push(s));
      }
    }
    if (S.routes[r.mode] !== r) return;
    const hits = [];
    for (const s of signs) {
      const w = s.location && s.location.wgs84; if (!w) continue;
      const p = [+w.longitude, +w.latitude];
      if (distToRoute(r, p) < 14) hits.push(s);
    }
    clearSigns();
    const li = [];
    hits.slice(0, 6).forEach((s) => {
      const w = s.location.wgs84, code = s.rvv_code;
      const extra = (s.text_signs || []).map((t) => t.text || t.description || '').filter(Boolean).join('; ');
      const road = s.location.road && s.location.road.name;
      li.push(`<li><span class="sign">${esc(code)}</span><span>Bord ${esc(code)} (${code === 'C13' ? 'gesloten voor bromfietsen' : 'gesloten voor fietsen en bromfietsen'}) bij ${esc(road || 'je route')}${extra ? ': ' + esc(extra) : ''}. Controleer ter plekke.</span></li>`);
      const el = document.createElement('div'); el.className = 'signpin'; el.textContent = code;
      signMarkers.push(new maplibregl.Marker({ element: el }).setLngLat([+w.longitude, +w.latitude]).addTo(map));
    });
    if (hits.length) $('warnList').insertAdjacentHTML('beforeend', li.join(''));
    r.signs = hits;
  } catch {
    if (S.routes[r.mode] === r) $('warnList').insertAdjacentHTML('beforeend', '<li class="info">Verkeersborden (NDW) konden nu niet worden gecontroleerd.</li>');
  }
}

/* ================= Navigatie ================= */
let wakeLock = null;
async function keepAwake(on) {
  const P = cap();
  try {
    if (P && P.KeepAwake) { on ? await P.KeepAwake.keepAwake() : await P.KeepAwake.allowSleep(); return; }
    if (on && 'wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen');
    else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
  } catch { /* niet ondersteund */ }
}
document.addEventListener('visibilitychange', () => { if (S.nav && document.visibilityState === 'visible') keepAwake(true); });

let nlVoice = null;
function pickVoice() {
  if (!('speechSynthesis' in window)) return;
  const vs = speechSynthesis.getVoices();
  nlVoice = vs.find((v) => /^nl(-|_)NL/i.test(v.lang)) || vs.find((v) => /^nl/i.test(v.lang)) || null;
}
if ('speechSynthesis' in window) { pickVoice(); speechSynthesis.onvoiceschanged = pickVoice; }
function say(text) {
  if (!settings.voice) return;
  const P = cap();
  if (P && P.TextToSpeech) { P.TextToSpeech.stop().catch(() => {}).finally(() => P.TextToSpeech.speak({ text, lang: 'nl-NL', rate: 1.0, volume: 1.0 }).catch(() => {})); return; }
  if (!('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.lang = 'nl-NL'; if (nlVoice) u.voice = nlVoice; u.rate = 1.02;
  speechSynthesis.speak(u);
}

$('btnStart').addEventListener('click', startNav);
async function startNav() {
  const r = S.routes[S.mode];
  if (!r) return;
  const sim = settings.sim;
  if (!sim) { try { await whenHere(8000); } catch { toast('Wachten op GPS… Ga even naar buiten of zet locatie aan.', 5000); return; } }
  S.nav = { route: r, sim, stepI: 0, announced: {}, off: 0, lastReroute: 0, progress: 0, segI: 0, follow: true, arrived: false, simT: null };
  document.body.classList.add('navigating');
  ['topbar', 'sheet', 'btnLocate'].forEach((id) => { $(id).hidden = true; });
  ['navTop', 'navBottom', 'navChips'].forEach((id) => { $(id).hidden = false; });
  document.documentElement.style.setProperty('--sheet-h', '0px');
  $('btnVoice').classList.toggle('muted', !settings.voice);
  keepAwake(true);
  pickVoice();
  const first = r.steps[0];
  say(`Route naar ${S.to ? S.to.name.split(',')[0] : 'je bestemming'}. ${fmtMin(r.time)} minuten. ` + (first && first.cmd !== 100 ? `Over ${speakDist(r.cum[first.idx])}, ${stepText(first, true).toLowerCase()}.` : ''));
  if (r.weather && r.weather.rain >= 0.1) pushChip('rain', 'Regen onderweg');
  if (r.signs && r.signs.length) pushChip('warn', `${r.signs.length} bord(en) bij route`);
  requestAnimationFrame(() => document.documentElement.style.setProperty('--nav-top-h', $('navTop').offsetHeight + 'px'));
  map.setPadding({ top: Math.round(window.innerHeight * 0.38), bottom: 90, left: 0, right: 0 });
  if (sim) startSim(); else onNavPosition();
  rainTimer = setInterval(navWeather, 10 * 60e3);
}
let rainTimer = null;
function pushChip(kind, text) {
  const el = document.createElement('div'); el.className = 'chip ' + kind; el.textContent = text; $('navChips').appendChild(el);
}
async function navWeather() {
  if (!S.nav || !S.here) return;
  try {
    const j = await fetchJSON(`${CFG.meteo}?latitude=${S.here.lat.toFixed(3)}&longitude=${S.here.lng.toFixed(3)}&minutely_15=precipitation&forecast_minutely_15=3&timezone=Europe%2FAmsterdam`, {}, 8000);
    const mx = Math.max(...j.minutely_15.precipitation);
    [...$('navChips').querySelectorAll('.rain')].forEach((e) => e.remove());
    if (mx >= 0.1) { pushChip('rain', 'Regen binnen 30 min'); say('Let op, binnen een half uur regen.'); }
  } catch { /* ok */ }
}

function stopNav() {
  if (!S.nav) return;
  if (S.nav.simT) clearInterval(S.nav.simT);
  clearInterval(rainTimer);
  S.nav = null;
  document.body.classList.remove('navigating');
  ['navTop', 'navBottom', 'navChips', 'navThen', 'btnRecenter'].forEach((id) => { $(id).hidden = true; });
  $('navChips').innerHTML = '';
  ['topbar', 'sheet', 'btnLocate'].forEach((id) => { $(id).hidden = false; });
  map.setPadding({ top: 0, bottom: 0, left: 0, right: 0 });
  map.easeTo({ pitch: 0, bearing: 0, duration: 500 });
  if (map.getSource('done')) map.getSource('done').setData(EMPTY);
  keepAwake(false);
  if ('speechSynthesis' in window) speechSynthesis.cancel();
  updateSheetH();
}
$('btnStop').addEventListener('click', stopNav);
$('btnVoice').addEventListener('click', () => {
  settings.voice = !settings.voice; saveSettings(); $('btnVoice').classList.toggle('muted', !settings.voice);
  toast(settings.voice ? 'Stem aan' : 'Stem uit', 1500);
});
$('btnRecenter').addEventListener('click', () => { if (S.nav) { S.nav.follow = true; $('btnRecenter').hidden = true; onNavPosition(); } });
map.on('dragstart', (e) => { if (S.nav && e.originalEvent) { S.nav.follow = false; $('btnRecenter').hidden = false; } });

// Positie op de route vastzetten
function snapToRoute(r, p, fromSeg) {
  const lo = Math.max(0, fromSeg - 3), hi = Math.min(r.coords.length - 2, fromSeg + 120);
  let best = { d: Infinity, i: fromSeg, t: 0 };
  const scan = (a, b) => {
    for (let i = a; i <= b; i++) {
      const q = projectOnSeg(p, r.coords[i], r.coords[i + 1]);
      if (q.d < best.d) best = { d: q.d, i, t: q.t };
    }
  };
  scan(lo, hi);
  if (best.d > 60) scan(0, r.coords.length - 2);
  const segLen = r.cum[best.i + 1] - r.cum[best.i];
  return { ...best, along: r.cum[best.i] + best.t * segLen };
}

function onNavPosition() {
  const N = S.nav; if (!N || !S.here) return;
  const r = N.route, p = [S.here.lng, S.here.lat];
  const sn = snapToRoute(r, p, N.segI);
  N.segI = sn.i;
  // Van de route af?
  const tol = Math.max(30, Math.min(70, (S.here.acc || 15) * 1.5));
  if (sn.d > tol) N.off++; else { N.off = 0; N.progress = Math.max(N.progress, sn.along); }
  if (N.off >= 3 && Date.now() - N.lastReroute > 15000 && !N.sim) { reroute(); return; }

  // Puck & camera
  const segB = bearing(r.coords[sn.i], r.coords[Math.min(sn.i + 1, r.coords.length - 1)]);
  const head = N.off ? (S.here.heading ?? segB) : segB;
  const shown = N.off ? p : pointAt(r, sn.along);
  puck.setLngLat(shown).setRotation(head);
  if (!puckOnMap) { puck.addTo(map); puckOnMap = true; }
  if (N.follow) {
    const kmh = (S.here.speed || 0) * 3.6;
    const z = kmh > 35 ? 16.3 : kmh > 18 ? 16.8 : 17.3;
    map.easeTo({ center: shown, bearing: head, pitch: 55, zoom: z, duration: 900, easing: (t) => t });
  }
  // Afgelegd deel grijs
  const doneCoords = r.coords.slice(0, sn.i + 1).concat([shown]);
  if (map.getSource('done') && doneCoords.length > 1) map.getSource('done').setData({ type: 'Feature', geometry: { type: 'LineString', coordinates: doneCoords } });

  // Volgende manoeuvre
  while (N.stepI < r.steps.length - 1 && r.cum[r.steps[N.stepI].idx] < N.progress + 3) N.stepI++;
  updateNavUI();

  // Snelheid
  const kmh = Math.round((S.hereSpeed = (S.here.speed || 0) * 3.6));
  $('speedVal').textContent = kmh;
  const vmax = S.mode === 'snor' ? settings.vmaxSnor : settings.vmaxBrom;
  $('speedo').classList.toggle('over', kmh > vmax + 3);

  // Aangekomen
  const left = r.length - N.progress;
  if (!N.arrived && (left < 25 || hav(p, r.coords[r.coords.length - 1]) < 25)) {
    N.arrived = true; say('Je bent aangekomen.');
    $('navText').textContent = 'Je bent aangekomen'; $('navDist').textContent = '';
    setTimeout(() => { if (S.nav && S.nav.arrived) stopNav(); }, 8000);
  }
}
function pointAt(r, along) {
  let i = 0; while (i < r.cum.length - 2 && r.cum[i + 1] < along) i++;
  const seg = r.cum[i + 1] - r.cum[i] || 1, t = Math.max(0, Math.min(1, (along - r.cum[i]) / seg));
  const a = r.coords[i], b = r.coords[i + 1];
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}

function updateNavUI(namesChanged) {
  const N = S.nav; if (!N) return;
  const r = N.route, s = r.steps[N.stepI];
  const dist = Math.max(0, r.cum[s.idx] - N.progress);
  if (!N.arrived) {
    $('navDist').textContent = fmtDist(dist);
    $('navText').textContent = stepText(s);
    $('navArrow').innerHTML = arrowSVG(s, '#ffffff');
  }
  const nxt = r.steps[N.stepI + 1];
  if (nxt && r.cum[nxt.idx] - r.cum[s.idx] < 150 && s.cmd !== 100) {
    $('navThen').hidden = false; $('navThenArrow').innerHTML = arrowSVG(nxt, '#eef2f5'); $('navThenText').textContent = stepText(nxt);
  } else $('navThen').hidden = true;
  const left = Math.max(0, r.length - N.progress);
  const tLeft = r.time * (left / r.length);
  $('navRemD').textContent = (left / 1000).toFixed(1).replace('.', ',');
  $('navRemT').textContent = fmtMin(tLeft);
  $('navEta').textContent = fmtClock(new Date(Date.now() + tLeft * 1000));
  if (namesChanged) return;
  // Gesproken aanwijzingen: ver, dichtbij, nu
  const m = MODES[S.mode], key = N.stepI;
  const A = N.announced[key] || (N.announced[key] = {});
  const legLen = r.cum[s.idx] - (N.stepI ? r.cum[r.steps[N.stepI - 1].idx] : 0);
  if (s.cmd === 100) {
    if (!A.far && dist < m.far && dist > m.near) { A.far = 1; say(`Over ${speakDist(dist)} ben je op je bestemming.`); }
    return;
  }
  if (!A.far && dist <= m.far && dist > m.near + 20 && legLen > m.far + 50) { A.far = 1; say(`Over ${speakDist(dist)}, ${stepText(s, true).toLowerCase()}.`); }
  else if (!A.near && dist <= m.near && dist > 18) {
    A.near = 1; A.far = 1;
    let t = `Over ${speakDist(dist)}, ${stepText(s, true).toLowerCase()}`;
    const nx = r.steps[N.stepI + 1];
    if (nx && nx.cmd !== 100 && r.cum[nx.idx] - r.cum[s.idx] < 80) t += `, daarna ${stepText(nx, true).toLowerCase()}`;
    say(t + '.');
  } else if (!A.now && dist <= 18) { A.now = A.near = A.far = 1; say(stepText(s, true) + '.'); }
}

async function reroute() {
  const N = S.nav; if (!N) return;
  N.lastReroute = Date.now(); N.off = 0;
  say('Route wordt opnieuw berekend.');
  try {
    const r = await fetchRoute(S.mode, [S.here.lng, S.here.lat], [S.to.lng, S.to.lat], 0);
    if (!S.nav) return;
    S.routes[S.mode] = r;
    Object.assign(N, { route: r, stepI: 0, announced: {}, progress: 0, segI: 0 });
    drawRoute(); nameSteps(r); onNavPosition();
  } catch (e) { toast(e.message); }
}

/* Testrit: rijdt de route af op ~vmax */
function startSim() {
  const N = S.nav, r = N.route, vmax = (S.mode === 'snor' ? settings.vmaxSnor : settings.vmaxBrom) / 3.6;
  let along = 0;
  toast('Testrit gestart (gesimuleerde GPS)', 2500);
  N.simT = setInterval(() => {
    if (!S.nav) return;
    along = Math.min(r.length, along + vmax * 1.0 * (0.85 + Math.random() * 0.15));
    const p = pointAt(S.nav.route, along);
    S.here = { lng: p[0], lat: p[1], speed: vmax * 0.95, heading: null, acc: 5, t: Date.now() };
    onNavPosition();
    if (along >= r.length) clearInterval(N.simT);
  }, 1000);
}

/* ================= Panelen & modus ================= */
function showPane(which) {
  $('paneHome').hidden = which !== 'home';
  $('paneRoute').hidden = which !== 'route';
  updateSheetH();
}
function updateSheetH() {
  requestAnimationFrame(() => {
    const wide = window.innerWidth >= 760;
    document.documentElement.style.setProperty('--sheet-h', wide || $('sheet').hidden ? '0px' : $('sheet').offsetHeight + 'px');
  });
}
new ResizeObserver(updateSheetH).observe($('sheet'));
function setMode(m) {
  if (S.mode === m) return;
  S.mode = m; store.set('mode', m); S.altIdx = 0;
  applyModeStyle();
  if (S.to) { if (S.routes[m]) showRoute(true); else planRoute(); }
}
document.querySelectorAll('.plate, .cmp').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));
$('btnClear').addEventListener('click', () => {
  S.to = null; S.from = null; S.routes = {}; $('inTo').value = ''; $('inFrom').value = '';
  destMarker.remove(); fromMarker.remove(); clearSigns(); drawRoute(); showPane('home'); renderHome();
});

/* ================= Instellingen ================= */
const dlg = $('dlgSettings');
$('btnSettings').addEventListener('click', () => {
  $('setVoice').checked = settings.voice; $('setBusySnor').checked = settings.busySnor; $('setBusyBrom').checked = settings.busyBrom;
  $('setNdw').checked = settings.ndw; $('setSim').checked = settings.sim;
  $('setVmaxSnor').value = settings.vmaxSnor; $('outVmaxSnor').textContent = settings.vmaxSnor;
  $('setVmaxBrom').value = settings.vmaxBrom; $('outVmaxBrom').textContent = settings.vmaxBrom;
  if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
});
$('setVmaxSnor').addEventListener('input', (e) => { $('outVmaxSnor').textContent = e.target.value; });
$('setVmaxBrom').addEventListener('input', (e) => { $('outVmaxBrom').textContent = e.target.value; });
dlg.addEventListener('close', () => {
  const before = JSON.stringify([settings.vmaxSnor, settings.vmaxBrom, settings.busySnor, settings.busyBrom, settings.ndw]);
  Object.assign(settings, {
    voice: $('setVoice').checked, busySnor: $('setBusySnor').checked, busyBrom: $('setBusyBrom').checked,
    ndw: $('setNdw').checked, sim: $('setSim').checked, vmaxSnor: +$('setVmaxSnor').value, vmaxBrom: +$('setVmaxBrom').value
  });
  saveSettings(); applyModeStyle();
  if (S.to && before !== JSON.stringify([settings.vmaxSnor, settings.vmaxBrom, settings.busySnor, settings.busyBrom, settings.ndw])) planRoute();
});

/* ================= Start ================= */
renderHome();
showPane('home');
applyModeStyle();
startGeo();
whenHere(15000).then((h) => { if (!S.to) map.jumpTo({ center: [h.lng, h.lat], zoom: 15 }); }).catch(() => {});
if ('serviceWorker' in navigator && location.protocol === 'https:' && !cap()) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
// Snelkoppelingen uit de manifest (?to=home / ?to=work)
const qTo = new URLSearchParams(location.search).get('to');
if (qTo && favs()[qTo]) setTimeout(() => setPoint('to', favs()[qTo]), 300);

// Export voor tests
if (typeof window !== 'undefined') window.__so = { S, settings, setPoint, startNav, stopNav, setMode, parseRoute, stepText, fmtDist };
