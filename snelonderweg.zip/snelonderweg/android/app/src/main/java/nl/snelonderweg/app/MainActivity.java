package nl.snelonderweg.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
