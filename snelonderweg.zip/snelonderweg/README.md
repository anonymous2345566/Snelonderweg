# SnelOnderweg

Gratis navigatie voor snorfiets (blauw kenteken, 25 km/h) en bromfiets (geel kenteken, 45 km/h) in Nederland. Werkt als webapp (installeerbaar op je startscherm) en als Android-app (APK).

## Wat het doet

- **Legale routes per kenteken** met eigen routeprofielen (`www/profiles/`):
  - Snorfiets: over fietspaden (G11/G12a), rijbaan alleen waar het moet. Rijbaanplicht-zones (zoals Amsterdam binnen de A10) volgen uit OpenStreetMap (`mofa=no` op die fietspaden). Onverplichte fietspaden (G13) worden gemeden. Snelle wegen zonder fietspad krijgen strafpunten.
  - Bromfiets: op de rijbaan, nooit over gewone fietspaden, wel over fiets/bromfietspaden (G12a). Verplicht bromfietspad naast de weg wordt gevolgd. Nooit over snelweg, autoweg of trunk.
  - Beide: geen wegen met C12/C13/C15 (`motor_vehicle=no`, `moped=no`), eenrichtingsverkeer, afslagverboden, slagbomen.
- **Snor vs. brom vergelijken**: elke route wordt voor beide kentekens berekend, je ziet direct het tijdsverschil.
- **Rijtijd** via een rijmodel met optrekken, afremmen, bochten en verkeerslichten, op basis van je topsnelheid (instelbaar, bijv. 40 voor een gedrosselde brommer).
- **Turn-by-turn navigatie** met Nederlandse gesproken aanwijzingen, straatnamen (PDOK), rotonde-afslagen, "daarna"-hint, automatisch herberekenen als je afwijkt, snelheidsmeter die rood wordt boven je max, scherm blijft aan.
- **Regen**: neerslag per kwartier voor start en bestemming, met advies wanneer je droog kunt vertrekken. Tijdens het rijden elke 10 minuten een check. Ook windstoten en gladheid.
- **Verkeersborden (NDW)**: borden C13 en C15 die vlak bij je route staan worden getoond, met onderborden.
- Zoeken op adres, straat, postcode, plaats (PDOK) en op plekken als scholen en winkels (Photon/OpenStreetMap). Lang drukken op de kaart kiest een bestemming.
- Thuis en Werk/school opslaan, recente bestemmingen, snelkoppelingen "Naar huis" via het app-icoon.
- **Testrit simuleren** (Instellingen): rijdt de route virtueel af, zodat je navigatie aan je bureau kunt testen.

Alles draait op gratis diensten zonder API-sleutel: BRouter (brouter.de), OpenFreeMap-kaarten, PDOK Locatieserver, Photon, Open-Meteo en NDW open data.

## Snelste weg: webapp op je telefoon

1. Zet de map `www/` online op een HTTPS-adres (eigen hosting, of GitHub Pages via de workflow hieronder). Locatie werkt alleen via HTTPS.
2. Open het adres in Chrome op je telefoon → menu ⋮ → **App installeren** / **Toevoegen aan startscherm**.

Lokaal testen op je pc: `npm run serve` en open http://localhost:8080 (localhost mag zonder HTTPS).

## Android-app (APK) zonder Android Studio

De workflow `.github/workflows/build.yml` bouwt de APK automatisch op GitHub:

1. Maak een (gratis) GitHub-repository aan, bijv. `snelonderweg`.
2. Upload de inhoud van deze map (zonder `node_modules`). Controleer dat `.github/workflows/build.yml` meekomt.
3. Ga naar **Settings → Pages** en kies bij *Source* **GitHub Actions** (voor de webversie).
4. Ga naar **Actions**: de workflow "Bouw app" draait vanzelf. Na ~5 minuten staat onder de run een download **SnelOnderweg-apk**.
5. Zet de APK op je telefoon en installeer (sta "installeren uit onbekende bronnen" toe).

Zelf bouwen met Android Studio kan ook: `npm install`, `npx cap sync android`, open de map `android/`.

## Aanpassen

- Routeregels: `www/profiles/snor.brf` en `brom.brf` (BRouter-profieltaal). Verhoog `PROFILE_VERSION` in `www/app.js` na een wijziging, dan uploadt de app het profiel opnieuw.
- Diensten en startpositie: bovenaan `www/app.js` (`CFG`).
- Test van de app-logica: `node test/flow.test.js` (vereist `npm i -D jsdom`).

## Grenzen

- BRouter, PDOK en Photon zijn publieke, gratis servers. Voor dagelijks gebruik door één persoon is dat prima; ga je de app breed verspreiden, draai dan een eigen BRouter-server (gratis software, Docker-image in de BRouter-repo).
- Routes zijn zo goed als de OpenStreetMap-data. Ontbreekt `moped=designated` op een G12a-pad, dan stuurt de brom-route je over de rijbaan ernaast. Borden langs de weg gaan altijd voor.
- De NDW-borden-API publiceert geen CORS-beleid; als de browser het verzoek blokkeert, meldt de app dat de borden niet gecontroleerd konden worden en werkt de rest gewoon.
- Navigatie met scherm uit (achtergrond-GPS) en Android Auto zitten er nog niet in.
